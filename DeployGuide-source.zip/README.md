# DeployGuide

An educational deployment documentation website. Choose one of six deployment paths, enter non-secret project details, and get a complete, locally generated guide explaining **why** each step exists. It never connects to a server or claims to verify one.

## Run locally

Requires Node.js 24 LTS and npm.

```sh
npm ci
npm run dev
```

Open the local URL printed by Next.js. The application has no backend, API routes, server actions, authentication, database, analytics, or runtime external API requests. Official source links open only when requested.

Run only one development server for this checkout. If Next.js reports “Another next dev server is already running,” use its existing URL, or stop that server with Ctrl+C in its original terminal before starting again. A second port does not permit a second dev server in the same project.

```sh
npm run typecheck
npm test
npm run build
npm run preview
```

The complete static website is emitted to **out/**. `npm run dev` is for development. Do not run `next start` for this exported website. Serve `out/` with a static HTTP server, an Nginx document root, or a static hosting provider. For Nginx, use `try_files $uri $uri/ =404;` and an appropriate document root. Deploy at an origin root; subdirectory hosting requires a deliberate Next.js `basePath` configuration and a rebuild.

`npm run preview` serves the exported files at http://127.0.0.1:4173 for local checks. It is a development tool, not an application backend or production server. Stop it with Ctrl+C. All dependencies are pinned in the manifest and lockfile so `npm ci` reproduces the checked versions.

## A shorter first deployment

- Plain HTML: **5 steps**. Prepare the server, upload public files, configure Nginx, connect DNS/HTTPS, and check the result.
- Vite and Next.js static export: **6 steps**, adding a **local** production build. These paths do not install Node, create a service, or configure a server-side environment file on the static server.
- Express, Next.js Node, and Laravel: **7 steps**. Runtime installation, application configuration, and process/PHP setup appear only where needed.

Each stage opens its first task and lets readers expand the rest. The explanations, prerequisites, checks, and troubleshooting remain available. Architecture and maintenance live under “When you need it” instead of inflating the launch checklist. Laravel migrations, uploads, queues, scheduling, encryption-key initialization, and frontend assets explain their conditions before exposing commands. Existing keys must be preserved.

The wizard asks for app name, domain, and IP up front; username, directory, repository, and Node port live in Advanced settings. It follows the app name when the directory still uses the default. The guide resumes at the saved step after reload. Checklist v2 uses new progress keys because the old thirteen-step checkmarks do not map reliably to the revised stages.

## Supported deployment guides

| Application              | Public request handling                       | Production output/runtime       |
| ------------------------ | --------------------------------------------- | ------------------------------- |
| HTML / CSS / JavaScript  | Nginx serves public files                     | `public/`; no runtime           |
| React + Vite             | Nginx serves static output, with SPA fallback | `dist/`; Node 24 for build only |
| Express                  | Nginx reverse-proxies a loopback process      | Node 24, managed by systemd     |
| Next.js static export    | Nginx serves generated routes                 | `out/`; Node 24 for build only  |
| Next.js Node application | Nginx reverse-proxies `next start`            | Node 24, managed by systemd     |
| Laravel 12               | Nginx serves `public/` and delegates PHP      | PHP 8.2, 8.3, 8.4 or 8.5 FPM    |

The Linux baseline is **Ubuntu 24.04 LTS**. **Windows Server 2022 and 2025, x64 Desktop Experience** have separate Apache 2.4 guides for all six paths. Apache serves static files, reverse-proxies Node, and loads the selected x64 Thread Safe (TS) PHP module for Laravel. Apache runs under the dedicated non-administrator `dg-httpd` account. One Apache instance uses one PHP version; multi-tenant isolation is outside this baseline. Node uses one WinSW Windows service under LocalService. PHP-FPM and systemd commands are never used as Windows instructions. Native Windows production queue workers/Horizon are outside this guide because PHP lacks PCNTL timeout support.

PHP **8.3** remains the Ubuntu default because it comes from Ubuntu 24.04's distribution repositories. **8.2, 8.4 and 8.5** use the explicitly disclosed third-party Ondřej Surý PPA. Package availability was checked against its Noble amd64 index. The selected version changes package names, CLI calls, FPM services, sockets and optional workers. PHP 8.5 is the latest stable branch reviewed; PHP 8.2 upstream security support ends 2026-12-31. Composer dependencies and extensions must independently support the selected version. No runtime API resolves “latest.”

Windows, PHP choices and CI/CD sources were reviewed on **2026-10-29**. Instructions have not been executed on live Ubuntu/Windows servers or in a connected GitHub repository during this revision. Website tests and syntax checks do not constitute production-server verification. See `VALIDATION.md` for the exact scope.

## Optional CI/CD automation

Each generated guide includes a separate **six-step GitHub Actions CI/CD section**, with its own locally saved checkmarks. It does not lengthen the 5–8-step first deployment. Search, print and Markdown include it; downloadable `deployguide.yml` and `deploy.sh` or `deploy.ps1` use the selected stack, OS, PHP version, package manager and application paths.

The documented default uses GitHub-hosted pull-request/push checks and a deliberate `workflow_dispatch` production release from protected `main`. The release job needs passing checks, a private repository and the `production` environment. A dedicated, non-administrator self-hosted deployment runner on the server polls GitHub over HTTPS. All repository workflow authors must be trusted with its account; labels are routing, not access controls. Private environments and independent approval features depend on the GitHub plan. No repository, runner, credentials or workflow are created by this website.

The guide covers the test contract, runner permissions, versioned releases, persistent secrets/data, one-time configuration changes, pipeline files, smoke tests and recovery. Action commits are pinned to reviewed release SHAs. Runtime dependencies are installed from lockfiles and production installation is checked in CI. Production PHP/Node state stays outside artifacts. Release switching retains old files and attempts recovery after activation/HTTP failures; this is not a zero-downtime guarantee. Laravel migrations, queue/scheduler coordination and optional public upload links require separately reviewed project-specific work. Database rollback is never implied by code rollback.

## Structure and architectural choices

```text
src/app/                 App Router server entry, metadata, static export, global styles
src/components/          Interactive browser UI, wizard, diagram, tabs, modal and code viewer
src/content/stacks.ts    Typed path metadata, defaults, review date and source registry
src/content/guides.ts    Structured teaching tasks, adapted to each stack
src/content/launch-flow.ts  Stack-specific 5–8 stage composition and optional work
src/content/windows-guides.ts  Apache/PowerShell teaching tasks and sources
src/content/databases.ts  Conditional MariaDB/MySQL setup and private Laravel settings
src/lib/apache.ts  Initial HTTP and final HTTPS Apache configuration
src/content/platforms.ts  Explicit OS/PHP versions, defaults and support notes
src/content/automation.ts  Optional six-step CI/CD setup, rationale and recovery
src/content/glossary.ts  Local definitions used by keyboard/touch disclosures
src/content/troubleshooting.ts  Symptom, cause, investigation and fix records
src/lib/types.ts         Shared strict TypeScript contracts
src/lib/commands.ts      Pure Nginx and systemd configuration generators
src/lib/windows-commands.ts  Windows roots and WinSW service XML
src/lib/cicd.ts          Pinned GitHub workflow and Bash/PowerShell release generators
src/lib/generator.ts     Public guide-generation interface
src/lib/validation.ts    Input constraints, POSIX quoting, configuration identity
src/lib/downloads.ts     Complete Markdown serialization and browser downloads
src/lib/themes.ts       Theme metadata; CSS custom properties define theme palettes
tests/                  Generation, validation, escaping and path regression tests
```

Next.js App Router pre-renders the app to static HTML. Interactive components hydrate in the browser because selection, filtering, local storage, clipboard and downloads need browser capabilities. The root page and layout remain server components at build time. No remote service is required by the finished app. Tailwind 4 is available for utilities; theme-aware CSS provides the documentation layout and all four palettes. Motion handles wizard/tab/diagram transitions and progress. Motion's `reducedMotion="user"` and CSS reduced-motion queries disable movement when requested.

Guide data uses a single typed `Step` contract for goal, rationale, mechanics, prerequisites, command blocks, breakdown, expected result, verification, problems and next action. Screen UI, Markdown and print consume the same data. Commands and configuration are never independently retyped in downloads.

Ubuntu uses Nginx and systemd; Windows uses Apache and one WinSW service for Node. Static sites have no application service. Laravel exposes only its public directory and executes only the PHP front controller. Screen UI, downloads and print consume the same typed content. Keeping OS-specific generators separate avoids mixing shells, service models and privilege assumptions.

## Input and command safety

- Every generator rejects invalid input before interpolation. Domain names, IPv4 addresses, non-root usernames, unprivileged TCP ports, application names and paths have narrow allowlists. Control characters, credentials in URLs, query strings, path traversal and unknown version combinations are rejected.
- Project directories are intentionally restricted to a direct child of `/var/www` or `C:\Sites`. Windows reserved filenames and shell control characters are rejected. Broad path support requires reviewing every target parser.
- Shell arguments use POSIX or PowerShell single-quote helpers. Nginx, systemd, XML and workflow values also pass narrow context-specific allowlists.
- Repository input accepts HTTPS without embedded credentials. The website never asks for passwords, private keys, tokens or environment secrets.
- Node processes run as a dedicated account and bind to loopback. The public firewall permits only the intended SSH and HTTP(S) access. Commands test Nginx before reloading.
- The example IP, `203.0.113.10`, is reserved for documentation. The UI calls this out before generation. Replace example values before deployment.

## Browser features

The workspace offers six stack cards, a validated wizard, local documentation search (`Ctrl/Cmd + K`), sticky step navigation, syntax-colored code with copy feedback, command explanations, expected-result tabs, an interactive request diagram, a symptom search, glossary disclosures, four persistent themes, a complete print layout, Markdown download and the initial HTTP Nginx configuration download.

The guide's architecture panel slides into a narrow right-hand rail on desktop, giving the instructions more room. Its arrow button reopens it. On smaller screens it is a collapsible section above the instructions, initially closed unless a saved preference says otherwise. The choice is saved locally; the toggle supports keyboard input, hidden controls leave the tab order, and animations respect reduced-motion preferences. `components/GuideLayout.tsx` owns this interaction separately from guide content.

The left navigation can also collapse into a 64px icon rail, with its own saved preference. Its toggle sits beside search when expanded. Search, guide steps and other destinations remain clickable when collapsed, with accessible names and hover labels. `components/DocumentationLayout.tsx` owns this layout and keeps the mobile menu independent of the desktop choice. Shared screen typography lives in `app/typography.css`: reading text is 16px, navigation is 14px, and commands are 13px by default, expressed in relative units. Phone layouts wrap controls and stack selection cards to preserve these readable sizes; print styling remains separate.

Checklist progress is saved under a canonical configuration key containing all builder settings. Editing the configuration switches to that configuration's own progress. A confirmed reset clears only the current checklist. A checkmark means **the user marked it complete**, never a server test. Storage failures keep the current session usable and display feedback. Clearing browser storage removes preferences and progress; Markdown remains a portable guide.

## Add a deployment path

1. Extend `StackId` and add typed metadata to `content/stacks.ts`.
2. Specify its deployment mode, public output, supported runtime and official documentation sources.
3. Extend the command generators and structured task content, then compose an appropriate launch path in `launch-flow.ts`. Keep every teaching field and verification path complete. Update `launchStepCount` and its regression cases.
4. Add a recognizable stack icon and validation rules for every new field or version. Avoid unrestricted executable inputs.
5. Add regression tests for its request path, service model, public root, downloads and invalid combinations.
6. Test generation in the browser, at mobile width, with keyboard input, all themes, reduced motion, print, and persisted progress.

Adding an OS version requires reviewed packages, runtime installation, service identities, permissions, web-server routing and automation behavior. Do not simply append a version to a dropdown. Add the baseline to `platforms.ts`, validation and the complete generation/escaping matrix. Review PHP support dates and framework compatibility separately from package availability.

## Maintaining technical accuracy

The primary source registry is in `content/stacks.ts`; additional official links accompany generated guides. Before changing the reviewed date, revisit the specific framework, Ubuntu, Nginx, systemd, runtime and Certbot sources; examine their actual compatibility requirements. Run the generator regression suite and static build. Separately test commands on disposable Ubuntu servers when available, including both fresh setup and update/recovery. Record the scope and outcome honestly; never equate unit tests or documentation review with server validation.

Pay particular attention to runtime support dates, NodeSource repository trust, PHP extension requirements, Certbot packaging, custom SSH ports, AAAA records, Next.js unsupported static features, browser-visible environment variables, queue timeouts and irreversible database changes. The guide uses the project lockfile and does not force dependency upgrades or destructive resets.

## Deployment files

`.openai/hosting.json` declares private Sites hosting of `out/`. The app itself is host-independent and contains no Site authentication or runtime integration code. Hosting access controls, if enabled by the provider, exist outside this static application.

### Laravel uploads, databases and React

Laravel has eight launch stages. Windows uses MariaDB 11.4 LTS with a private loopback listener; Ubuntu uses its packaged MySQL. The database task explains how to skip provisioning when an existing/managed database is already prepared. Credentials are entered only on the server and are never requested by the site. Database account names are derived from validated application names with the MySQL length limit.

Git and ZIP/secured transfer instructions explain the actual project root, lockfiles, exclusions and preview-before-copy workflow. Laravel React/Inertia remains one Laravel application: build Vite locally and transfer `public/build`. The guide separates required frontend output from conditional migrations, public-storage links, scheduling and queues. SSR, Reverb and native Windows queue workers require additional reviewed designs.

Windows certificate setup uses win-acme filesystem validation, protected PEM files and an administrator-owned test/restart script. Initial downloads contain HTTP configuration so they do not refer to certificates before issuance; the HTTPS task contains the complete final configuration. CI/CD preserves that Apache configuration outside releases and changes only the reviewed document root to the release junction. Windows and Laravel progress use a new content revision so old checkmarks do not mark the changed tasks complete.

The Apache/MariaDB changes were reviewed against linked primary documentation on 2026-10-30. Automated generation, parsing and browser checks do not establish compatibility on a live Windows or Ubuntu server; rehearse the generated instructions on a matching staging server before production.
