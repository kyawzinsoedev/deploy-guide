export type StackId =
  "html" | "vite" | "express" | "next-static" | "next-node" | "laravel";
export type DeploymentMode = "static" | "node" | "php";
export type PackageManager = "npm" | "pnpm";
export interface GuideConfig {
  stack: StackId;
  os: "24.04";
  appName: string;
  domain: string;
  www: boolean;
  serverIp: string;
  username: string;
  directory: string;
  repository: string;
  packageManager: PackageManager;
  port: string;
  runtime: "24" | "8.3" | "none";
}
export interface Source {
  label: string;
  url: string;
}
export interface Stack {
  id: StackId;
  name: string;
  subtitle: string;
  mode: DeploymentMode;
  badge: string;
  description: string;
  runtime: GuideConfig["runtime"];
  sources: Source[];
}
export interface Problem {
  symptom: string;
  cause: string;
  fix: string;
  tags: string[];
}
export interface CodeBlock {
  title: string;
  language: "bash" | "nginx" | "ini" | "javascript" | "text";
  code: string;
  location:
    | "Your computer"
    | "Server · administrator"
    | "Server · deployment user"
    | "Configuration";
  changes: boolean;
  optional?: string;
}
export interface Step {
  id: string;
  title: string;
  goal: string;
  why: string;
  how: string;
  before: string;
  blocks: CodeBlock[];
  breakdown: { term: string; explanation: string }[];
  expected: string;
  verification: CodeBlock;
  problems: Problem[];
  next: string;
  note?: string;
  /** Small tasks in a launch stage, with their own location and checks. */
  parts?: Step[];
}
export interface Guide {
  config: GuideConfig;
  stack: Stack;
  steps: Step[];
  nginx: string;
  sources: Source[];
  reviewedOn: string;
  references?: Step[];
}
