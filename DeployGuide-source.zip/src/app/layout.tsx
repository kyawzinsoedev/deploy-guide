import type { Metadata } from "next";
import "./globals.css";
import "./flow.css";
export const metadata: Metadata = {
  title: "DeployGuide — From localhost to live.",
  description:
    "Understand every step of deploying to Linux with Nginx. Personalized, locally generated guides for React, Node.js, Next.js, Laravel and static websites.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" data-theme="paper" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
